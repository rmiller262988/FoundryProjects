## Fully decentralized application published on IPFS

## 🔧 Project Diagram:
![Project Diagram/Workflow](https://i.gyazo.com/827138d2e256cffbe00e34a15afa39e2.png)
