const sha256 = require('js-sha256'); // npm install js-sha256

//Alice has a secret document she wants to sent. She does not want to reveal personal information and will use bblockchain to send a pre image hash
