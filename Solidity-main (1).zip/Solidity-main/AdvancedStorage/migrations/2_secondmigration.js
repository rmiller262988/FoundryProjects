const AdvancedStorage = artifacts.require("AdvancedStorage");

module.exports = function(deployer) {
  deployer.deploy(AdvancedStorage);
};