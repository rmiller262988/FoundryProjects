const AithisiToken = artifacts.require("AisthisiToken");

module.exports = function (deployer) {
    deployer.deploy(AisthisiToken);
};